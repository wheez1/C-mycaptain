
#include <iostream>
using namespace std;

int main() 
{    int a,b;
int product;
    cout<< "Enter a numbers: ";
    cin>> a;
    cout<< "Enter another numbers: ";
    cin>> b;
    product= a * b;
    cout<< "Product ="<< product;
    
    
    return 0;
}